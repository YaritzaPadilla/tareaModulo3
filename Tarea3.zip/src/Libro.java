
    
import java.util.ArrayList;
import java.util.List;

class Libro {
    String titulo, autor, genero;
    boolean disponible;
    List<Integer> calificaciones;
    List<String> comentarios;

    public Libro(String titulo, String autor, String genero) {
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.disponible = true;
        this.calificaciones = new ArrayList<>();
        this.comentarios = new ArrayList<>();
    }

    void prestar() { 
        disponible = false; 
        System.out.println("Libro prestado: " + titulo);
    }

    void devolver() { 
        disponible = true; 
        System.out.println("Libro devuelto: " + titulo);
    }

    void calificar(int calificacion) {
        if (calificacion >= 1 && calificacion <= 5) {
            calificaciones.add(calificacion);
            System.out.println("Calificación añadida.");
        } else {
            System.out.println("Debe ser entre 1 y 5.");
        }
    }

    void comentar(String comentario) {
        comentarios.add(comentario);
        System.out.println("Comentario añadido.");
    }

    void mostrarInfo() {
        System.out.println("Título: " + titulo + " | Autor: " + autor + " | Género: " + genero + 
                           " | Disponible: " + (disponible ? "Sí" : "No"));
    }
}

