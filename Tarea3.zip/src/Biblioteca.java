import java.util.ArrayList;
import java.util.List;

class Biblioteca {
    List<Libro> libros = new ArrayList<>();

    void agregarLibro(Libro libro) { libros.add(libro); }

    void buscar(String palabra) {
        for (Libro libro : libros) {
            if (libro.titulo.contains(palabra) || libro.autor.contains(palabra)) {
                libro.mostrarInfo();
            }
        }
    }

    void prestar(String titulo) {
        for (Libro libro : libros) {
            if (libro.titulo.equalsIgnoreCase(titulo) && libro.disponible) {
                libro.prestar();
                return;
            }
        }
        System.out.println("No disponible.");
    }

    void devolver(String titulo) {
        for (Libro libro : libros) {
            if (libro.titulo.equalsIgnoreCase(titulo) && !libro.disponible) {
                libro.devolver();
                return;
            }
        }
        System.out.println("No encontrado.");
    }

    void calificar(String titulo, int calificacion) {
        for (Libro libro : libros) {
            if (libro.titulo.equalsIgnoreCase(titulo)) {
                libro.calificar(calificacion);
                return;
            }
        }
        System.out.println("Libro no encontrado.");
    }

    void comentar(String titulo, String comentario) {
        for (Libro libro : libros) {
            if (libro.titulo.equalsIgnoreCase(titulo)) {
                libro.comentar(comentario);
                return;
            }
        }
        System.out.println("Libro no encontrado.");
    }

    void mostrarDisponibles() {
        for (Libro libro : libros) {
            if (libro.disponible) libro.mostrarInfo();
        }
    }
}