import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        Scanner scanner = new Scanner(System.in);

        biblioteca.agregarLibro(new Libro("El Principito", "Antoine de Saint-Exupéry", "Ficción"));
        biblioteca.agregarLibro(new Libro("1984", "George Orwell", "Distopía"));

        while (true) {
            System.out.println("\n1. Buscar libro\n2. Prestar libro\n3. Devolver libro\n4. Calificar libro\n5. Comentar libro\n6. Ver disponibles\n7. Salir");
            int opcion = scanner.nextInt();
            scanner.nextLine(); 

            if (opcion == 7) break;

            System.out.print("Título o autor: ");
            String entrada = scanner.nextLine();

            switch (opcion) {
                case 1 -> biblioteca.buscar(entrada);
                case 2 -> biblioteca.prestar(entrada);
                case 3 -> biblioteca.devolver(entrada);
                case 4 -> {
                    System.out.print("Calificación (1-5): ");
                    int calificacion = scanner.nextInt();
                    biblioteca.calificar(entrada, calificacion);
                }
                case 5 -> {
                    System.out.print("Comentario: ");
                    String comentario = scanner.nextLine();
                    biblioteca.comentar(entrada, comentario);
                }
                case 6 -> biblioteca.mostrarDisponibles();
                default -> System.out.println("Opción no válida.");
            }
        }
        scanner.close();
    }
}